// Copyright Folding Sky Games LLC 2021 All rights reserved.

#include "K2Node_FoldingSkyStoryCustom.h"
/*
UK2Node_FoldingSkyStoryOneWayCustom::UK2Node_FoldingSkyStoryOneWayCustom(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	NodeType = EFoldingSkyStoryNodeType::CustomNode;
	SetNumChoices(0);
}
UK2Node_FoldingSkyStoryTwoWayCustom::UK2Node_FoldingSkyStoryTwoWayCustom(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	NodeType = EFoldingSkyStoryNodeType::CustomNode;
	SetNumChoices(-1);
}
UK2Node_FoldingSkyStoryWithChoicesCustom::UK2Node_FoldingSkyStoryWithChoicesCustom(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	NodeType = EFoldingSkyStoryNodeType::CustomNode;
	SetNumChoices(1);
}
*/