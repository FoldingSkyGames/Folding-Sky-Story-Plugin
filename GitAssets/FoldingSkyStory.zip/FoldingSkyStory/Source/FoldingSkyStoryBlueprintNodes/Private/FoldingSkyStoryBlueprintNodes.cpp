// Copyright Folding Sky Games LLC 2021 All rights reserved.

#include "FoldingSkyStoryBlueprintNodes.h"

IMPLEMENT_MODULE(FFoldingSkyStoryBlueprintNodesModule, FoldingSkyStoryBlueprintNodes)