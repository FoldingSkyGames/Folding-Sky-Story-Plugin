// Copyright Folding Sky Games LLC 2021 All rights reserved.

#include "FoldingSkyStoryEditor.h"

IMPLEMENT_MODULE(FFoldingSkyStoryEditorModule, FoldingSkyStoryEditor)